'use client';
import { useEffect, useState } from 'react';
import { Header } from '@/components/layout/Header';
import { supabase } from '@/lib/supabase';
import { Home, Search } from 'lucide-react';

export default function ImoveisPage() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (supabase as any).from('classified_listings')
      .select('*, mini_sites(slug, site_name, avatar_url)')
      .eq('type', 'imovel').eq('status', 'active')
      .order('created_at', { ascending: false })
      .then((r: any) => { setItems(r.data || []); setLoading(false); });
  }, []);

  const filtered = items.filter(i =>
    !search || i.title?.toLowerCase().includes(search.toLowerCase()) || i.location?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[var(--bg)]">
      <Header />
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
            <Home className="w-5 h-5 text-brand" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-[var(--text)]">Properties</h1>
            <p className="text-sm text-[var(--text2)]">Independent realtors with verified mini sites</p>
          </div>
        </div>

        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text2)]" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="input pl-9 max-w-md" placeholder="Search property, neighborhood..." />
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card overflow-hidden animate-pulse">
                <div className="aspect-video bg-[var(--bg2)]" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-[var(--bg2)] rounded w-3/4" />
                  <div className="h-5 bg-[var(--bg2)] rounded w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <Home className="w-12 h-12 text-[var(--text2)]/30 mx-auto mb-3" />
            <p className="text-[var(--text2)] font-semibold">No properties found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(item => (
              <div key={item.id} className="card overflow-hidden hover:border-brand/50 transition-all">
                {Array.isArray(item.images) && item.images[0] ? (
                  <img src={item.images[0]} alt="" className="aspect-video w-full object-cover" />
                ) : (
                  <div className="aspect-video bg-[var(--bg2)] flex items-center justify-center">
                    <Home className="w-8 h-8 text-[var(--text2)]/30" />
                  </div>
                )}
                <div className="p-4">
                  <h3 className="font-black text-[var(--text)] truncate">{item.title}</h3>
                  {item.price && (
                    <p className="text-brand font-black text-lg mt-1">
                      R$ {Number(item.price).toLocaleString('pt-BR')}
                    </p>
                  )}
                  {item.location && <p className="text-xs text-[var(--text2)] mt-1">📍 {item.location}</p>}
                  <div className="flex gap-2 mt-2 flex-wrap">
                    {item.extra?.tipo && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.tipo}</span>}
                    {item.extra?.quartos && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.quartos} bd</span>}
                    {item.extra?.m2 && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.m2} m²</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

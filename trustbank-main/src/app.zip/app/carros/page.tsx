'use client';
import { useEffect, useState } from 'react';
import { Header } from '@/components/layout/Header';
import { supabase } from '@/lib/supabase';
import { Car, Search } from 'lucide-react';

const BRANDS = ['All', 'Toyota', 'Honda', 'Volkswagen', 'Chevrolet', 'Ford', 'Hyundai', 'BMW', 'Mercedes'];

export default function CarrosPage() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [brand, setBrand] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (supabase as any).from('classified_listings')
      .select('*, mini_sites(slug, site_name)')
      .eq('type', 'carro').eq('status', 'active')
      .order('created_at', { ascending: false })
      .then((r: any) => { setItems(r.data || []); setLoading(false); });
  }, []);

  const filtered = items.filter(i => {
    const matchSearch = !search || i.title?.toLowerCase().includes(search.toLowerCase());
    const matchBrand = brand === 'All' || i.extra?.marca?.toLowerCase().includes(brand.toLowerCase());
    return matchSearch && matchBrand;
  });

  return (
    <div className="min-h-screen bg-[var(--bg)]">
      <Header />
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center">
            <Car className="w-5 h-5 text-brand" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-[var(--text)]">Cars</h1>
            <p className="text-sm text-[var(--text2)]">Independent sellers with verified mini sites</p>
          </div>
        </div>

        <div className="flex gap-3 mb-4 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text2)]" />
            <input value={search} onChange={e => setSearch(e.target.value)}
              className="input pl-9" placeholder="Search model, year..." />
          </div>
        </div>

        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {BRANDS.map(b => (
            <button key={b} onClick={() => setBrand(b)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border-2 transition-all ${
                brand === b ? 'bg-brand text-white border-brand' : 'border-[var(--border)] text-[var(--text2)] hover:border-brand/50'
              }`}>
              {b}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card overflow-hidden animate-pulse">
                <div className="aspect-video bg-[var(--bg2)]" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-[var(--bg2)] rounded w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <Car className="w-12 h-12 text-[var(--text2)]/30 mx-auto mb-3" />
            <p className="text-[var(--text2)] font-semibold">No cars found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(item => (
              <div key={item.id} className="card overflow-hidden hover:border-brand/50 transition-all">
                {Array.isArray(item.images) && item.images[0] ? (
                  <img src={item.images[0]} alt="" className="aspect-video w-full object-cover" />
                ) : (
                  <div className="aspect-video bg-[var(--bg2)] flex items-center justify-center">
                    <Car className="w-8 h-8 text-[var(--text2)]/30" />
                  </div>
                )}
                <div className="p-4">
                  <h3 className="font-black text-[var(--text)] truncate">{item.title}</h3>
                  {item.price && (
                    <p className="text-brand font-black text-lg mt-1">
                      R$ {Number(item.price).toLocaleString('pt-BR')}
                    </p>
                  )}
                  <div className="flex gap-2 mt-2 flex-wrap">
                    {item.extra?.marca && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.marca}</span>}
                    {item.extra?.ano && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.ano}</span>}
                    {item.extra?.km && <span className="text-xs bg-[var(--bg2)] px-2 py-0.5 rounded-full text-[var(--text2)]">{item.extra.km} km</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

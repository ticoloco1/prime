'use client';
import { usePublicSite } from '@/hooks/useSite';
import { useParams } from 'next/navigation';
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { ExternalLink, ChevronDown, ChevronUp, Home, Car, Lock, Send, Pin, Trash2, Share2, QrCode, X } from 'lucide-react';
import { Countdown } from '@/components/ui/Countdown';
import { useCart } from '@/store/cart';
import { toast } from 'sonner';

const THEMES: Record<string, string> = {
  midnight: 'from-slate-900 via-gray-900 to-zinc-900',
  cosmic: 'from-purple-900 via-indigo-900 to-violet-900',
  ocean: 'from-blue-900 via-cyan-900 to-teal-900',
  forest: 'from-emerald-900 via-green-900 to-teal-900',
  sunset: 'from-orange-900 via-amber-900 to-yellow-900',
  neon: 'from-fuchsia-900 via-pink-900 to-rose-900',
  noir: 'from-black via-gray-950 to-black',
  ember: 'from-stone-950 via-orange-950 to-stone-900',
  arctic: 'from-slate-900 via-blue-950 to-slate-900',
  rose: 'from-rose-950 via-pink-950 to-slate-900',
  gold: 'from-yellow-950 via-amber-950 to-stone-900',
};

export default function SitePage() {
  const params = useParams();
  const slug = params.slug as string;
  const { site, loading, notFound } = usePublicSite(slug);
  const { user } = useAuth();
  const { add: addToCart, open: openCart } = useCart();
  const [links, setLinks] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [classifieds, setClassifieds] = useState<any[]>([]);
  const [cvOpen, setCvOpen] = useState(false);
  const [posts, setPosts] = useState<any[]>([]);
  const [postText, setPostText] = useState('');
  const [postImages, setPostImages] = useState<string[]>([]);
  const [posting, setPosting] = useState(false);
  const [pinMode, setPinMode] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [unlockedVideos, setUnlockedVideos] = useState<Set<string>>(new Set());
  const isOwner = user?.id === site?.user_id;

  const loadPosts = useCallback(async (siteId: string) => {
    const { data } = await supabase.from('feed_posts' as any)
      .select('*').eq('site_id', siteId)
      .order('pinned', { ascending: false })
      .order('created_at', { ascending: false }).limit(20);
    const now = new Date();
    setPosts((data || []).filter((p: any) => p.pinned || new Date(p.expires_at) > now));
  }, []);

  useEffect(() => {
    if (!site?.id) return;
    supabase.from('mini_site_links').select('*').eq('site_id', site.id).order('sort_order').then(r => setLinks(r.data || []));
    supabase.from('mini_site_videos').select('*').eq('site_id', site.id).order('sort_order').then(r => setVideos(r.data || []));
    (supabase as any).from('classified_listings').select('*').eq('site_id', site.id).eq('status', 'active').then((r: any) => setClassifieds(r.data || []));
    loadPosts(site.id);
    if (user) {
      supabase.from('paywall_unlocks' as any).select('video_id').eq('user_id', user.id)
        .gt('expires_at', new Date().toISOString())
        .then(r => setUnlockedVideos(new Set((r.data || []).map((u: any) => u.video_id))));
    }
  }, [site?.id, user?.id, loadPosts]);

  const handlePaywall = (video: any) => {
    if (!user) { toast.error('Sign in to watch'); return; }
    if (unlockedVideos.has(video.id)) return;
    addToCart({ id: `video_${video.id}`, label: `Watch: ${video.title}`, price: video.paywall_price || 0.15, type: 'plan' });
    openCart();
  };

  const uploadPostImage = async (file: File) => {
    if (!user) return;
    const path = `${user.id}/feed/${Date.now()}_${file.name.replace(/[^a-z0-9.]/gi, '_')}`;
    const { error } = await supabase.storage.from('platform-assets').upload(path, file, { upsert: true });
    if (error) { toast.error(error.message); return; }
    setPostImages(p => [...p, supabase.storage.from('platform-assets').getPublicUrl(path).data.publicUrl]);
  };

  const submitPost = async () => {
    if (!postText.trim() || !user || !site) return;
    if (pinMode) {
      addToCart({ id: `pin_${Date.now()}`, label: 'Pin post for 365 days', price: 10, type: 'plan' });
      openCart();
      setPinMode(false);
      return;
    }
    setPosting(true);
    await supabase.from('feed_posts' as any).insert({
      site_id: site.id, user_id: user.id, text: postText.trim(),
      pinned: false, expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      image_url: postImages[0] || null,
    });
    setPostText(''); setPostImages([]); loadPosts(site.id);
    setPosting(false);
  };

  const deletePost = async (id: string) => {
    await supabase.from('feed_posts' as any).delete().eq('id', id);
    setPosts(p => p.filter((x: any) => x.id !== id));
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  if (loading) return <div className="min-h-screen bg-slate-900 flex items-center justify-center"><div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" /></div>;
  if (notFound || !site) return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white text-center"><div><p className="text-6xl mb-4">🔍</p><h1 className="text-2xl font-black">/{slug} not found</h1></div></div>;

  const theme = THEMES[site.theme] || THEMES.midnight;
  const accent = site.accent_color || '#818cf8';
  const imoveis = classifieds.filter(c => c.type === 'imovel');
  const carros = classifieds.filter(c => c.type === 'carro');
  // Video columns: mobile=2, desktop=3 or 4
  const vc = (site as any).video_cols || 2;
  const videoColsMobile = vc === 1 ? 'grid-cols-1' : 'grid-cols-2';
  const videoColsDesktop = vc >= 3 ? 'md:grid-cols-4' : vc === 2 ? 'md:grid-cols-3' : 'md:grid-cols-1';
  const photoSz = (site as any).photo_size || 'md';
  const photoW = photoSz === 'xl' ? 160 : photoSz === 'lg' ? 128 : photoSz === 'sm' ? 80 : 112;
  const cvLocked = (site as any).cv_locked !== false;

  const bgStyle: React.CSSProperties = site.bg_image_url ? {
    backgroundImage: `url(${site.bg_image_url})`, backgroundSize: 'cover',
    backgroundPosition: 'center', backgroundAttachment: 'fixed',
  } : {};

  return (
    <div className={`min-h-screen ${!site.bg_image_url ? `bg-gradient-to-b ${theme}` : ''}`} style={bgStyle}>
      {site.bg_image_url && <div className="fixed inset-0 bg-black/60 z-0 pointer-events-none" />}
      <div className="relative z-10">

        {/* Banner full width */}
        {site.banner_url
          ? <div className="w-full h-52 md:h-64"><img src={site.banner_url} alt="" className="w-full h-full object-cover" /></div>
          : <div className="h-32 md:h-40" style={{ background: `linear-gradient(135deg, ${accent}40, ${accent}10)` }} />
        }

        {/* Content — wider on desktop */}
        <div className="max-w-5xl mx-auto px-4 md:px-8">

          {/* Profile */}
          <div className="flex flex-col items-center text-center mt-6 mb-8">
            <div className="border-4 border-black overflow-hidden mb-4 shadow-2xl"
              style={{
                borderRadius: site.photo_shape === 'square' ? '16px' : site.photo_shape === 'rounded' ? '24px' : '50%',
                width: `${photoW}px`, height: `${photoW}px`,
              }}>
              {site.avatar_url
                ? <img src={site.avatar_url} alt="" className="w-full h-full object-cover" />
                : <div className="w-full h-full flex items-center justify-center font-black text-4xl" style={{ background: accent, color: '#fff' }}>{site.site_name?.[0]?.toUpperCase()}</div>
              }
            </div>
            <h1 className="font-black text-white mb-1 drop-shadow-lg"
              style={{ fontSize: site.font_size === 'xl' ? '2.5rem' : site.font_size === 'lg' ? '2rem' : site.font_size === 'sm' ? '1.2rem' : '1.75rem' }}>
              {site.site_name}
            </h1>
            {site.bio && <p className="text-white/80 text-sm md:text-base mb-2 max-w-xl">{site.bio}</p>}
            {site.cv_headline && <p className="text-sm font-semibold mb-4" style={{ color: accent }}>{site.cv_headline}</p>}

            <div className="flex gap-3 mb-2">
              <button onClick={() => setShowShare(!showShare)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 text-white/70 text-xs hover:bg-white/20 border border-white/20">
                <Share2 className="w-3 h-3" /> Share
              </button>
              <button onClick={() => setShowQr(!showQr)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 text-white/70 text-xs hover:bg-white/20 border border-white/20">
                <QrCode className="w-3 h-3" /> QR Code
              </button>
            </div>

            {showShare && (
              <div className="bg-black/60 backdrop-blur rounded-2xl p-4 mb-3 border border-white/10 w-full max-w-sm">
                <div className="flex gap-2 justify-center flex-wrap">
                  {[
                    { label: '🔗 Copy', action: () => { navigator.clipboard.writeText(shareUrl); toast.success('Copied!'); } },
                    { label: '𝕏 X', action: () => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}`) },
                    { label: '💬 WhatsApp', action: () => window.open(`https://wa.me/?text=${encodeURIComponent(shareUrl)}`) },
                    { label: '📘 Facebook', action: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`) },
                  ].map(s => <button key={s.label} onClick={s.action} className="px-3 py-1.5 bg-white/10 rounded-xl text-xs text-white hover:bg-white/20">{s.label}</button>)}
                </div>
              </div>
            )}
            {showQr && (
              <div className="bg-white rounded-2xl p-4 mb-3 inline-block">
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`} alt="QR" className="w-44 h-44 mx-auto" />
                <p className="text-slate-500 text-xs mt-2 font-mono text-center">/{slug}</p>
              </div>
            )}
          </div>

          {/* Feed */}
          <div className="mb-8 max-w-2xl mx-auto">
            {isOwner && (
              <div className="bg-black/40 rounded-2xl border border-white/10 p-4 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <label className="px-2 py-1 rounded text-xs border border-white/20 text-white/50 cursor-pointer hover:border-white/40">
                    📷 Photo
                    <input type="file" accept="image/*" className="hidden" onChange={e => e.target.files?.[0] && uploadPostImage(e.target.files[0])} />
                  </label>
                  {postImages.map((img, i) => (
                    <div key={i} className="relative">
                      <img src={img} alt="" className="w-8 h-8 rounded object-cover" />
                      <button onClick={() => setPostImages(p => p.filter((_, j) => j !== i))} className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center"><X className="w-2 h-2 text-white" /></button>
                    </div>
                  ))}
                </div>
                <textarea value={postText} onChange={e => setPostText(e.target.value)}
                  className="w-full bg-transparent text-white text-sm resize-none outline-none placeholder-white/30 mb-3"
                  rows={3} placeholder="What's on your mind?" maxLength={500} />
                <div className="flex items-center justify-between">
                  <div className="flex gap-2 items-center">
                    <span className="text-xs text-white/30">{postText.length}/500</span>
                    <button onClick={() => setPinMode(!pinMode)}
                      className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg border transition-all ${pinMode ? 'border-amber-400 text-amber-400 bg-amber-400/10' : 'border-white/20 text-white/40'}`}>
                      <Pin className="w-3 h-3" /> {pinMode ? 'Pin 365d ($10)' : 'Pin?'}
                    </button>
                  </div>
                  <button onClick={submitPost} disabled={!postText.trim() || posting}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-white text-xs font-semibold disabled:opacity-40"
                    style={{ background: accent }}>
                    <Send className="w-3 h-3" />{pinMode ? 'Pin ($10)' : 'Post'}
                  </button>
                </div>
              </div>
            )}
            {posts.map((post: any) => (
              <div key={post.id} className={`rounded-2xl p-4 border mb-3 ${post.pinned ? 'bg-amber-500/10 border-amber-500/40' : 'bg-white/5 border-white/10'}`}>
                {post.pinned && <div className="flex items-center gap-1 mb-2"><Pin className="w-3 h-3 text-amber-400" /><span className="text-xs text-amber-400 font-bold">Pinned</span></div>}
                <p className="text-white text-sm whitespace-pre-wrap">{post.text}</p>
                {post.image_url && <img src={post.image_url} alt="" className="mt-2 rounded-xl w-full object-cover max-h-64" />}
                <div className="flex items-center justify-between mt-3">
                  {!post.pinned ? <Countdown expiresAt={post.expires_at} /> : <span className="text-xs text-amber-400/60">Until {new Date(post.pinned_until || post.expires_at).toLocaleDateString()}</span>}
                  {isOwner && <button onClick={() => deletePost(post.id)} className="text-red-400/50 hover:text-red-400 ml-auto"><Trash2 className="w-3.5 h-3.5" /></button>}
                </div>
              </div>
            ))}
          </div>

          {/* Links — full width on desktop */}
          {links.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-10 max-w-4xl mx-auto">
              {links.map(link => (
                <a key={link.id} href={link.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center justify-between px-6 py-4 rounded-2xl font-semibold text-sm text-white transition-all hover:opacity-80 active:scale-[0.98]"
                  style={{ background: `${accent}25`, border: `1px solid ${accent}40` }}>
                  <span>{link.title}</span>
                  <ExternalLink className="w-4 h-4 opacity-50" />
                </a>
              ))}
            </div>
          )}

          {/* Videos — 3-4 cols on desktop, no piracy (no autoplay, embed only) */}
          {videos.length > 0 && (
            <div className="mb-10">
              <h2 className="font-black text-white mb-4 text-lg">Videos</h2>
              <div className={`grid ${videoColsMobile} ${videoColsDesktop} gap-4`}>
                {videos.map(video => (
                  <div key={video.id} className="rounded-2xl overflow-hidden bg-black/30 border border-white/10">
                    {video.paywall_enabled && !unlockedVideos.has(video.id) ? (
                      <button onClick={() => handlePaywall(video)} className="w-full relative aspect-video block group">
                        {/* Use thumbnail only - no embed until paid */}
                        <img
                          src={`https://img.youtube.com/vi/${video.youtube_video_id}/hqdefault.jpg`}
                          alt={video.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center gap-2 group-hover:bg-black/60 transition-all">
                          <div className="w-12 h-12 rounded-full bg-white/10 border-2 border-white/30 flex items-center justify-center">
                            <Lock className="w-5 h-5 text-white" />
                          </div>
                          <span className="text-white font-black">${video.paywall_price} USDC</span>
                          <span className="text-white/60 text-xs">Tap to unlock</span>
                        </div>
                      </button>
                    ) : (
                      // Only embed after unlock - prevents piracy
                      <iframe
                        src={`https://www.youtube-nocookie.com/embed/${video.youtube_video_id}?rel=0&modestbranding=1`}
                        className="w-full aspect-video"
                        allowFullScreen
                        allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        title={video.title}
                      />
                    )}
                    <p className="text-white/70 text-xs px-3 py-2">{video.title}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CV */}
          {site.show_cv && (
            <div className="mb-10 rounded-2xl border border-white/10 overflow-hidden max-w-2xl mx-auto" style={{ background: 'rgba(0,0,0,0.3)' }}>
              <button onClick={() => setCvOpen(!cvOpen)} className="w-full flex items-center justify-between px-5 py-4 text-white font-semibold text-sm">
                <span>CV / Resume</span>{cvOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {cvOpen && (
                <div className="px-5 pb-5">
                  {site.cv_content && <div className="text-sm text-slate-300 mb-4" dangerouslySetInnerHTML={{ __html: site.cv_content }} />}
                  {(site.cv_skills || []).length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs font-bold text-slate-400 uppercase mb-2">Skills</p>
                      <div className="flex flex-wrap gap-2">
                        {site.cv_skills.map((s: string) => <span key={s} className="text-xs px-2 py-1 rounded-full" style={{ background: `${accent}20`, color: accent }}>{s}</span>)}
                      </div>
                    </div>
                  )}
                  {(site.contact_email || site.contact_phone) && (
                    <div className="border-t border-white/10 pt-4">
                      {cvLocked
                        ? <button onClick={() => { addToCart({ id: 'cv_unlock', label: `Unlock ${site.site_name} contact`, price: site.contact_price || 20, type: 'plan' }); openCart(); }}
                            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm border border-white/20 hover:border-white/40 text-white/70" style={{ background: `${accent}15` }}>
                            <Lock className="w-4 h-4" /> Unlock Contact — ${site.contact_price} USDC
                          </button>
                        : <div className="space-y-2">
                            {site.contact_email && <a href={`mailto:${site.contact_email}`} className="flex items-center gap-2 text-sm" style={{ color: accent }}>✉️ {site.contact_email}</a>}
                            {site.contact_phone && <a href={`tel:${site.contact_phone}`} className="flex items-center gap-2 text-sm" style={{ color: accent }}>📞 {site.contact_phone}</a>}
                          </div>
                      }
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Properties — 2 cols on desktop */}
          {imoveis.length > 0 && (
            <div className="mb-10">
              <h2 className="font-black text-white mb-4 text-lg flex items-center gap-2"><Home className="w-5 h-5" /> Properties</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {imoveis.map((item: any) => (
                  <div key={item.id} className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: 'rgba(0,0,0,0.35)' }}>
                    {Array.isArray(item.images) && item.images.length > 0 && (
                      <div className="overflow-x-auto flex gap-2 p-2 snap-x snap-mandatory">
                        {item.images.map((img: string, i: number) => (
                          <img key={i} src={img} alt="" className="h-44 w-full min-w-full object-cover rounded-xl shrink-0 snap-start" style={{ minWidth: '100%' }} />
                        ))}
                      </div>
                    )}
                    {(!item.images || item.images.length === 0) && <div className="h-44 bg-white/5 flex items-center justify-center"><Home className="w-10 h-10 text-white/20" /></div>}
                    <div className="p-4">
                      <h3 className="font-black text-white text-base">{item.title}</h3>
                      {item.price && <p className="text-xl font-black mt-1" style={{ color: accent }}>{item.extra?.currency === 'USD' ? `$${Number(item.price).toLocaleString()}` : `R$ ${Number(item.price).toLocaleString('pt-BR')}`}</p>}
                      {item.location && <p className="text-xs text-slate-400 mt-1">📍 {item.location}</p>}
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {item.extra?.tipo && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.tipo}</span>}
                        {item.extra?.quartos && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.quartos} bd</span>}
                        {item.extra?.m2 && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.m2} m²</span>}
                      </div>
                      {item.extra?.contact && <a href={`https://wa.me/${item.extra.contact.replace(/\D/g, '')}`} target="_blank" className="inline-flex items-center gap-1 mt-3 text-xs font-bold px-3 py-1.5 rounded-xl" style={{ background: `${accent}30`, color: accent }}>📞 WhatsApp</a>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cars — 2-3 cols on desktop */}
          {carros.length > 0 && (
            <div className="mb-10">
              <h2 className="font-black text-white mb-4 text-lg flex items-center gap-2"><Car className="w-5 h-5" /> Cars</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {carros.map((item: any) => (
                  <div key={item.id} className="rounded-2xl border border-white/10 overflow-hidden" style={{ background: 'rgba(0,0,0,0.35)' }}>
                    {Array.isArray(item.images) && item.images.length > 0 && (
                      <div className="overflow-x-auto flex gap-2 p-2 snap-x snap-mandatory">
                        {item.images.map((img: string, i: number) => (
                          <img key={i} src={img} alt="" className="h-44 object-cover rounded-xl shrink-0 snap-start" style={{ minWidth: '100%', width: '100%' }} />
                        ))}
                      </div>
                    )}
                    {(!item.images || item.images.length === 0) && <div className="h-44 bg-white/5 flex items-center justify-center"><Car className="w-10 h-10 text-white/20" /></div>}
                    <div className="p-4">
                      <h3 className="font-black text-white text-base">{item.title}</h3>
                      {item.price && <p className="text-xl font-black mt-1" style={{ color: accent }}>{item.extra?.currency === 'USD' ? `$${Number(item.price).toLocaleString()}` : `R$ ${Number(item.price).toLocaleString('pt-BR')}`}</p>}
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {item.extra?.marca && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.marca}</span>}
                        {item.extra?.ano && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.ano}</span>}
                        {item.extra?.km && <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-slate-300">{item.extra.km} km</span>}
                      </div>
                      {item.extra?.contact_type === 'link' && item.extra?.link
                        ? <a href={item.extra.link} target="_blank" className="inline-flex items-center gap-1 mt-3 text-xs font-bold px-3 py-1.5 rounded-xl" style={{ background: `${accent}30`, color: accent }}>🔗 View Listing</a>
                        : item.extra?.contact && <a href={`https://wa.me/${item.extra.contact.replace(/\D/g,'')}`} target="_blank" className="inline-flex items-center gap-1 mt-3 text-xs font-bold px-3 py-1.5 rounded-xl" style={{ background: `${accent}30`, color: accent }}>📞 WhatsApp</a>
                      }
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <p className="text-center text-xs text-white/20 py-8">Powered by TrustBank</p>
        </div>
      </div>
    </div>
  );
}
